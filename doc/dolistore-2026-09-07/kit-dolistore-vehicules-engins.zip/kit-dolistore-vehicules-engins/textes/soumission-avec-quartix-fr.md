# Champs Dolistore — Français

## Nom du module/produit

Gestion des véhicules et engins

## Description courte

Votre parc roule. Vous gardez le contrôle. Affectations, consommations, entretiens, assurances, contrôles et dossier PDF/ZIP : pilotez votre parc dans Dolibarr. L’intégration QUARTIX ajoute les kilométrages estimés, l’utilisation et les trajets disponibles.

## Description longue

# Votre parc roule. Vous gardez le contrôle.

Les informations dispersées ralentissent vos équipes. **Gestion des véhicules et engins** rassemble votre parc dans Dolibarr pour relier le suivi quotidien, les échéances et les documents utiles.

## L’essentiel de votre parc, à portée de main

- **Sachez qui utilise quoi :** affectations, périodes d’utilisation et historique kilométrique.
- **Comprenez vos consommations :** carburant, recharge électrique, additifs, coûts renseignés et graphiques.
- **Préparez les échéances :** contrôles, contrats d’assurance, attestations et rappels configurables.
- **Reliez entretien et dépenses :** interventions, pannes et incidents associés aux factures fournisseurs Dolibarr.
- **Rassemblez le dossier véhicule :** synthèse PDF et archive ZIP des pièces éligibles.
- **Travaillez dans votre ERP :** droits granulaires, fichiers joints natifs et compatibilité Multicompany.

Pour les entreprises du bâtiment, installateurs, équipes de maintenance et responsables de parc qui veulent retrouver une information exploitable au bon endroit.

## Déjà équipé QUARTIX ?

Retrouvez dans Dolibarr les kilométrages estimés, dernières positions connues, données d’utilisation et trajets autorisés disponibles. Des droits GPS dédiés encadrent l’accès ; les trajets privés restent protégés.

Véhicules équipés, accès QUARTIX QWS v2 autorisé et synchronisations configurées requis. Matériel et services QUARTIX non inclus. Données issues de la dernière synchronisation disponible ; unités de durée à confirmer.

**Donnez à votre parc une place centrale dans Dolibarr, du premier relevé au dossier véhicule.**

## Avant de commencer

- Dolibarr 20+, PHP 8.0+, MySQL/MariaDB. Interface du module : français et anglais.
- Factures fournisseurs et PHP ZipArchive nécessaires au dossier véhicule. Rappels automatiques : travaux planifiés activés et configurés.
- Suivi des contrôles fondé sur un catalogue réglementaire français ; le module ne réalise pas les contrôles et ne produit pas de rapports officiels.
- Le dossier PDF/ZIP exclut les justificatifs des consommations, de leurs opérations bancaires et les données GPS.
